function f(x)
    x * x
end

cos(1)
sin(1)
